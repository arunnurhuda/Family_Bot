/**
* jangan dihapus/diganti ya kontol
* lu itu cuma make jadi jangan diapa apain ya bangsat
* mending lu tambahin deh nama lu jangan hapus kreditnya
**/

let handler = async (m, { conn, usedPrefix }) => {
    let tqto = `*BIG THANKS TO*

Nurutomo: 
https://github.com/Nurutomo
Istikmal: 
https://github.com/BochilGaming
Ariffb: 
https://github.com/Ariffb25
Aguz Familia:
https://github.com/FokusDotId
Amelia Lisa:
https://github.com/Ameliascrf
Aniq12
https://github.com/aniq12
Ilman: 
https://github.com/ilmanhdyt
Amirul: 
https://github.com/amiruldev20
Irwan:
https://github.com/irwanx
Rasel:
https://github.com/raselcomel

\`\`\`${conn.user.name}\`\`\`
`
    const _0x5ec2bc=_0x513f;(function(_0x39a2de,_0xd3db15){const _0x564f04=_0x513f,_0x58b7a9=_0x39a2de();while(!![]){try{const _0x5cf0b9=parseInt(_0x564f04(0x93))/0x1+-parseInt(_0x564f04(0x92))/0x2*(-parseInt(_0x564f04(0x8e))/0x3)+-parseInt(_0x564f04(0x94))/0x4*(parseInt(_0x564f04(0x98))/0x5)+parseInt(_0x564f04(0x8a))/0x6*(-parseInt(_0x564f04(0x97))/0x7)+parseInt(_0x564f04(0x9e))/0x8*(parseInt(_0x564f04(0x9c))/0x9)+-parseInt(_0x564f04(0x9d))/0xa+parseInt(_0x564f04(0x96))/0xb*(-parseInt(_0x564f04(0x89))/0xc);if(_0x5cf0b9===_0xd3db15)break;else _0x58b7a9['push'](_0x58b7a9['shift']());}catch(_0x4c72ec){_0x58b7a9['push'](_0x58b7a9['shift']());}}}(_0x3ab1,0x331e1));const buttons=[{'buttonId':usedPrefix+'sc','buttonText':{'displayText':_0x5ec2bc(0x99)},'type':0x1}],logo=await(await fetch(_0x5ec2bc(0x9b)))['buffer'](),buttonMessage={'document':{'url':_0x5ec2bc(0x8b)},'mimetype':global[_0x5ec2bc(0x90)],'fileName':global[_0x5ec2bc(0x9a)],'fileLength':0x32788364a337f,'pageCount':0x1056e0f36a64440000000,'contextInfo':{'forwardingScore':0x1869f,'isForwarded':!![],'externalAdReply':{'mediaUrl':'https://wa.me/6281320170984','mediaType':0x2,'previewType':_0x5ec2bc(0x91),'title':_0x5ec2bc(0x8c)+global['u'],'body':_0x5ec2bc(0x95),'thumbnail':logo,'sourceUrl':_0x5ec2bc(0x8f)}},'caption':tqto,'footer':'ʙy\x20ᴀɢᴜᴢ\x20ꜰᴀᴍɪʟɪᴀ','buttons':buttons,'headerType':0x1};return await conn[_0x5ec2bc(0x8d)](m.chat,buttonMessage,{'quoted':m,'ephemeralExpiration':0x15180,'forwardingScore':0x1869f,'isForwarded':!![]});function _0x513f(_0x356ff8,_0xd69cca){const _0x3ab11c=_0x3ab1();return _0x513f=function(_0x513f40,_0x4ea6d0){_0x513f40=_0x513f40-0x89;let _0x3e45fc=_0x3ab11c[_0x513f40];return _0x3e45fc;},_0x513f(_0x356ff8,_0xd69cca);}function _0x3ab1(){const _0x2ddc13=['PHOTO','41556mAOWSl','315029mfxoHR','12mXoIIK','ʙy\x20ᴀɢᴜᴢ\x20ꜰᴀᴍɪʟɪᴀ','22rYgXim','7SSUbEY','126965OFojcR','Source\x20Code\x20Bot\x20✨','ucapan','https://telegra.ph/file/38ff21d724ecd78d7d0f8.jpg','459wZVMhI','3088760AXxbRp','63472BQeoOC','198780iZpkyW','1674618puSpKb','https://wa.me/6281320170984','aktif\x20selama\x20:\x20','sendMessage','27XpEzWF','https://www.instagram.com/aguzfamilia','doc'];_0x3ab1=function(){return _0x2ddc13;};return _0x3ab1();}
}
handler.help = ['tqto']
handler.tags = ['info']
handler.command = /^(credits?|thanks?to|tqto|ttq)$/i

module.exports = handler
